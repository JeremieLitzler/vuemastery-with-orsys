import VueRouter from 'vue-router';
import Login from "../pages/Login";
import Home from "../pages/Home";
import Vue from 'vue';

// On active le module dans Vue
Vue.use(VueRouter);

export default new VueRouter({
    mode: 'history', // On active le HTML5 mode pour éviter les url avec /#!/
    base: '/',
    routes: [
        {
            path: '/login',
            name: 'login',
            component: Login,
            beforeEnter(to, from, next) {
                // On va vérifier qu'il n'est pas déjà connecté avant d'accéder à cette page
                // Si déjà connecté, on redirige simplement vers la page home

                // process.env.STORAGE_TOKEN_KEY permet de récupérer une variable d'environnement dans le fichier .env
                const valueToken = localStorage.getItem(process.env.VUE_APP_STORAGE_TOKEN_KEY);

                if (valueToken) {
                    next({name: 'home'});
                } else {
                    next();
                }
            },

        },
        {
            path: '/home',
            name: 'home',
            component: Home,
            beforeEnter(to, from, next) {
                const valueToken = localStorage.getItem(process.env.VUE_APP_STORAGE_TOKEN_KEY);

                if (!valueToken) {
                    // En redirigeant, on passe un paramètre pour indiquer qu'il n'est pas connecté
                    next({name: 'login', query: {notLogged: true}});
                } else {
                    next();
                }
            },
        },
        {
            path: '*', // Joker, marche avec toutes les routes. Vue lit de haut en bas, s'il arrive là, alors on redirige
            redirect: '/login'
        }
    ]
})